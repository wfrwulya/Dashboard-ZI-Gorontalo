
import os, re, io, json, hmac, sqlite3, datetime as dt
from pathlib import Path

import pandas as pd
import openpyxl
import streamlit as st
import plotly.express as px

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
SAMPLE_DIR = APP_DIR / "sample_data"
DB_PATH = DATA_DIR / "zi_dashboard.db"
DATA_DIR.mkdir(exist_ok=True)

st.set_page_config(
    page_title="Monitoring ZI Gorontalo",
    page_icon="📊",
    layout="wide",
)

AREA_NAMES = [
    "MANAJEMEN PERUBAHAN",
    "PENATAAN TATALAKSANA",
    "PENATAAN SISTEM MANAJEMEN SDM APARATUR",
    "PENGUATAN AKUNTABILITAS",
    "PENGUATAN PENGAWASAN",
    "PENINGKATAN KUALITAS PELAYANAN PUBLIK",
]

def db():
    con = sqlite3.connect(DB_PATH)
    con.execute("""
        CREATE TABLE IF NOT EXISTS summary (
            satker TEXT PRIMARY KEY,
            total_rb REAL,
            pengungkit REAL,
            pengungkit_pct REAL,
            hasil REAL,
            hasil_pct REAL,
            min_area_pct REAL,
            status TEXT,
            updated_at TEXT,
            source_file TEXT,
            area_json TEXT,
            result_json TEXT
        )
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS points (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            satker TEXT,
            section TEXT,
            component_no TEXT,
            component TEXT,
            sub_no TEXT,
            subcomponent TEXT,
            code TEXT,
            indicator TEXT,
            answer TEXT,
            score REAL,
            score_pct REAL,
            review_note TEXT,
            tl_r INTEGER,
            tl_s INTEGER,
            tl_t INTEGER,
            pic TEXT,
            link TEXT,
            source_row INTEGER
        )
    """)
    con.commit()
    return con

def numeric_score_cells(ws, row, minv=None, maxv=None):
    out = []
    for c in range(8, 14):
        v = ws.cell(row, c).value
        if isinstance(v, (int, float)):
            if (minv is None or v >= minv) and (maxv is None or v <= maxv):
                out.append(v)
    return out

def extract_summary(file_bytes, satker, source_file):
    wb = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=True)
    if "Utama" not in wb.sheetnames:
        raise ValueError("Sheet 'Utama' tidak ditemukan.")
    ws = wb["Utama"]

    total_rb = pengungkit = pengungkit_pct = hasil = hasil_pct = None
    for r in range(1, ws.max_row + 1):
        b = ws.cell(r, 2).value
        if not isinstance(b, str):
            continue
        label = b.strip().upper()
        if label == "NILAI EVALUASI REFORMASI BIROKRASI":
            vals = numeric_score_cells(ws, r, minv=1.01)
            total_rb = vals[-1] if vals else None
        elif label == "TOTAL PENGUNGKIT":
            vals = numeric_score_cells(ws, r, minv=1.01)
            pengungkit = vals[-1] if vals else None
            pcts = numeric_score_cells(ws, r, minv=0, maxv=1)
            pengungkit_pct = pcts[-1] if pcts else None
        elif label == "TOTAL HASIL":
            vals = numeric_score_cells(ws, r, minv=1.01)
            hasil = vals[-1] if vals else None
            pcts = numeric_score_cells(ws, r, minv=0, maxv=1)
            hasil_pct = pcts[-1] if pcts else None

    if total_rb is None or pengungkit is None:
        raise ValueError(
            "Nilai ringkasan tidak terbaca. Pastikan file LKE sudah dibuka dan disimpan di Excel "
            "agar formula memiliki nilai hasil perhitungan."
        )

    areas = []
    for r in range(6, 12):
        nums = numeric_score_cells(ws, r, minv=1.01)
        pcts = numeric_score_cells(ws, r, minv=0, maxv=1)
        areas.append({
            "no": str(ws.cell(r, 4).value).strip(".") if ws.cell(r, 4).value else str(r - 5),
            "name": str(ws.cell(r, 5).value).strip() if ws.cell(r, 5).value else AREA_NAMES[r - 6],
            "weight": ws.cell(r, 8).value,
            "score": nums[-1] if nums else None,
            "pct": pcts[-1] if pcts else None,
        })

    results = []
    for r in (15, 18):
        nums = numeric_score_cells(ws, r, minv=1.01)
        pcts = numeric_score_cells(ws, r, minv=0, maxv=1)
        name = ws.cell(r, 4).value or ws.cell(r, 5).value
        results.append({
            "name": str(name).strip() if name else "",
            "weight": ws.cell(r, 8).value,
            "score": nums[-1] if nums else None,
            "pct": pcts[-1] if pcts else None,
        })

    min_area_pct = min(a["pct"] for a in areas if isinstance(a["pct"], (int, float)))
    status = (
        "MEMENUHI"
        if total_rb >= 75 and pengungkit >= 40 and min_area_pct >= 0.60
        else "BELUM MEMENUHI"
    )

    return {
        "satker": satker,
        "total_rb": total_rb,
        "pengungkit": pengungkit,
        "pengungkit_pct": pengungkit_pct,
        "hasil": hasil,
        "hasil_pct": hasil_pct,
        "min_area_pct": min_area_pct,
        "status": status,
        "areas": areas,
        "results": results,
        "source_file": source_file,
        "updated_at": dt.datetime.now().isoformat(timespec="seconds"),
    }

def extract_points(file_bytes, satker):
    wb = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=True)
    if "Jawaban" not in wb.sheetnames:
        raise ValueError("Sheet 'Jawaban' tidak ditemukan.")
    ws = wb["Jawaban"]

    section = None
    area_no = area_name = None
    sub_no = sub_name = None
    result_no = result_name = None
    rows = []

    for r in range(2, 205):
        c, d, e, f, g = [ws.cell(r, col).value for col in range(3, 8)]
        if c in ("PENGUNGKIT", "HASIL"):
            section = c

        if section == "PENGUNGKIT":
            if d and isinstance(d, str) and re.match(r"^\d+\.$", d.strip()) and e:
                area_no = d.strip().rstrip(".")
                area_name = str(e).strip()
                sub_no = sub_name = None

            if e and isinstance(e, str) and re.match(r"^[ivx]+\.$", e.strip().lower()):
                sub_no = e.strip().rstrip(".")
                sub_name = str(f).strip() if f else ""

            j = ws.cell(r, 10).value
            n = ws.cell(r, 14).value
            if g is not None and j is not None and n is not None:
                fclean = str(f).strip().rstrip(".") if f is not None else ""
                helper = (
                    isinstance(g, str)
                    and g.strip().startswith("- ")
                    and fclean in ("", "-")
                )
                if not helper:
                    rows.append({
                        "satker": satker,
                        "section": "PENGUNGKIT",
                        "component_no": area_no,
                        "component": area_name,
                        "sub_no": sub_no or "",
                        "subcomponent": sub_name or "",
                        "code": f"A.{area_no}.{sub_no}.{fclean or '-'}",
                        "indicator": str(g).strip(),
                        "answer": str(n),
                        "score": ws.cell(r, 15).value,
                        "score_pct": ws.cell(r, 16).value,
                        "review_note": ws.cell(r, 17).value,
                        "tl_r": int(ws.cell(r, 18).value is True),
                        "tl_s": int(ws.cell(r, 19).value is True),
                        "tl_t": int(ws.cell(r, 20).value is True),
                        "pic": ws.cell(r, 22).value,
                        "link": ws.cell(r, 13).value,
                        "source_row": r,
                    })

        elif section == "HASIL":
            if (
                c
                and isinstance(c, str)
                and re.match(r"^[ivx]+\.$", c.strip().lower())
                and d
            ):
                result_no = c.strip().rstrip(".")
                result_name = str(d).strip()

            j = ws.cell(r, 10).value
            n = ws.cell(r, 14).value
            if e is not None and j is not None and n is not None:
                dclean = str(d).strip().rstrip(".") if d is not None else "-"
                rows.append({
                    "satker": satker,
                    "section": "HASIL",
                    "component_no": result_no,
                    "component": result_name,
                    "sub_no": "",
                    "subcomponent": "",
                    "code": f"B.{result_no}.{dclean}",
                    "indicator": str(e).strip(),
                    "answer": str(n),
                    "score": ws.cell(r, 15).value,
                    "score_pct": ws.cell(r, 16).value,
                    "review_note": ws.cell(r, 17).value,
                    "tl_r": int(ws.cell(r, 18).value is True),
                    "tl_s": int(ws.cell(r, 19).value is True),
                    "tl_t": int(ws.cell(r, 20).value is True),
                    "pic": ws.cell(r, 22).value,
                    "link": ws.cell(r, 13).value,
                    "source_row": r,
                })
    return rows

def load_data():
    con = db()
    summary = pd.read_sql_query("SELECT * FROM summary", con)
    points = pd.read_sql_query("SELECT * FROM points", con)
    con.close()
    return summary, points

def save_import(summary, points):
    con = db()
    satker = summary["satker"]
    con.execute("DELETE FROM summary WHERE satker = ?", (satker,))
    con.execute("DELETE FROM points WHERE satker = ?", (satker,))
    con.execute(
        """INSERT INTO summary VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            summary["satker"], summary["total_rb"], summary["pengungkit"],
            summary["pengungkit_pct"], summary["hasil"], summary["hasil_pct"],
            summary["min_area_pct"], summary["status"], summary["updated_at"],
            summary["source_file"], json.dumps(summary["areas"], ensure_ascii=False),
            json.dumps(summary["results"], ensure_ascii=False),
        ),
    )
    for p in points:
        con.execute(
            """INSERT INTO points
            (satker,section,component_no,component,sub_no,subcomponent,code,indicator,
             answer,score,score_pct,review_note,tl_r,tl_s,tl_t,pic,link,source_row)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                p["satker"], p["section"], p["component_no"], p["component"],
                p["sub_no"], p["subcomponent"], p["code"], p["indicator"],
                p["answer"], p["score"], p["score_pct"], p["review_note"],
                p["tl_r"], p["tl_s"], p["tl_t"], p["pic"], p["link"], p["source_row"],
            ),
        )
    con.commit()
    con.close()

def seed_sample_data():
    summary, points = load_data()
    if not summary.empty:
        return
    if not SAMPLE_DIR.exists():
        return

    mapping = [
        ("LKE Kantah Kab Gorontalo.xlsx", "Kantah Kabupaten Gorontalo"),
        ("LKE Kanwil BPN Gorontalo 2026. (1).xlsx", "Kanwil BPN Provinsi Gorontalo"),
    ]
    for filename, satker in mapping:
        path = SAMPLE_DIR / filename
        if path.exists():
            raw = path.read_bytes()
            s = extract_summary(raw, satker, filename)
            p = extract_points(raw, satker)
            save_import(s, p)

def admin_password():
    value = os.getenv("ZI_ADMIN_PASSWORD", "")
    try:
        value = st.secrets.get("ADMIN_PASSWORD", value)
    except Exception:
        pass
    return value

def is_admin():
    return st.session_state.get("admin_authenticated", False)

def status_counts(df):
    if df.empty:
        return 0, 0
    return int((df["status"] == "MEMENUHI").sum()), int((df["status"] != "MEMENUHI").sum())

def tl_summary(points, satker=None):
    df = points.copy()
    if satker:
        df = df[df["satker"] == satker]
    if df.empty:
        return pd.DataFrame()

    out = []
    for component, g in df.groupby("component", sort=False):
        total = len(g)
        r = int(g["tl_r"].sum())
        s = int(g["tl_s"].sum())
        t = int(g["tl_t"].sum())
        pct = (r + s + t) / (total * 3) if total else 0
        out.append({
            "Komponen": component,
            "Total Poin": total,
            "Catatan TPI": r,
            "Eviden 2024-2025": s,
            "Penamaan Eviden": t,
            "Checklist": r + s + t,
            "TL %": pct,
        })
    return pd.DataFrame(out)

def fmt_pct(v):
    return f"{v:.1%}" if isinstance(v, (int, float)) else "-"

seed_sample_data()
summary, points = load_data()

st.sidebar.title("Monitoring ZI")
page = st.sidebar.radio("Menu", ["Dashboard", "Progress Satker", "Admin"])
st.sidebar.caption("Viewer dapat mengakses Dashboard & Progress. Fitur upload dikunci untuk Admin.")

if summary.empty:
    st.warning("Belum ada data LKE. Admin perlu mengunggah file LKE terlebih dahulu.")
    if page != "Admin":
        st.stop()

if page == "Dashboard":
    st.title("📊 Dashboard Monitoring Pembangunan ZI")
    st.caption("Provinsi Gorontalo • Kriteria WBK: Nilai RB ≥ 75, Pengungkit ≥ 40, dan setiap area pengungkit ≥ 60%")

    n = len(summary)
    memenuhi, belum = status_counts(summary)
    avg_rb = summary["total_rb"].mean() if n else 0
    satker_tl = []
    for satker in summary["satker"]:
        p = points[points["satker"] == satker]
        total_checks = len(p) * 3
        pct = (p[["tl_r", "tl_s", "tl_t"]].sum().sum() / total_checks) if total_checks else 0
        satker_tl.append({"Satker": satker, "TL %": pct})
    avg_tl = pd.DataFrame(satker_tl)["TL %"].mean() if satker_tl else 0

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Jumlah Satker Diusulkan", n)
    c2.metric("Memenuhi Syarat WBK", memenuhi)
    c3.metric("Rata-rata Nilai RB", f"{avg_rb:.2f}")
    c4.metric("Rata-rata Tindak Lanjut", f"{avg_tl:.1%}")

    left, right = st.columns([1.05, 1.45])
    with left:
        st.subheader("Tindak Lanjut per Satker")
        if satker_tl:
            tl_df = pd.DataFrame(satker_tl).sort_values("TL %")
            fig = px.bar(tl_df, x="TL %", y="Satker", orientation="h", text="TL %",
                         range_x=[0, 1])
            fig.update_traces(texttemplate="%{text:.1%}", textposition="outside")
            fig.update_layout(xaxis_tickformat=".0%", height=360, margin=dict(l=10,r=10,t=30,b=10))
            st.plotly_chart(fig, use_container_width=True)

    with right:
        st.subheader("Peringkat Nilai Satker")
        rank = summary.sort_values("total_rb", ascending=False).copy()
        rank.insert(0, "Peringkat", range(1, len(rank) + 1))
        rank["Nilai RB"] = rank["total_rb"].round(2)
        rank["Pengungkit"] = rank["pengungkit"].round(2)
        rank["Min Area"] = rank["min_area_pct"].map(fmt_pct)
        rank["Status"] = rank["status"].map({"MEMENUHI": "Memenuhi", "BELUM MEMENUHI": "Belum Memenuhi"})
        rank["TL %"] = [next(x["TL %"] for x in satker_tl if x["Satker"] == s) for s in rank["satker"]]
        rank["TL %"] = rank["TL %"].map(fmt_pct)
        st.dataframe(rank[["Peringkat","satker","Nilai RB","Pengungkit","Min Area","TL %","Status"]].rename(columns={"satker":"Satker"}),
                     use_container_width=True, hide_index=True)

    st.subheader("Kriteria Status Memenuhi Syarat WBK")
    st.dataframe(pd.DataFrame({
        "Kriteria": ["Nilai RB", "Nilai Pengungkit", "Nilai minimal setiap area pengungkit"],
        "Batas": ["≥ 75", "≥ 40", "≥ 60%"],
    }), use_container_width=True, hide_index=True)

elif page == "Progress Satker":
    st.title("📈 Progress Pembangunan ZI Satker")
    if summary.empty:
        st.info("Belum ada data.")
        st.stop()

    satkers = summary["satker"].tolist()
    selected = st.selectbox("Pilih Satker", satkers)
    srow = summary[summary["satker"] == selected].iloc[0]
    selected_points = points[points["satker"] == selected].copy()

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Nilai RB", f"{srow['total_rb']:.2f}")
    c2.metric("Nilai Pengungkit", f"{srow['pengungkit']:.2f} / 60")
    c3.metric("Nilai Hasil", f"{srow['hasil']:.2f} / 40")
    c4.metric("Status WBK", "Memenuhi" if srow["status"] == "MEMENUHI" else "Belum Memenuhi")

    st.subheader("1. Nilai Area Perubahan & Komponen Hasil")
    areas = json.loads(srow["area_json"])
    results = json.loads(srow["result_json"])
    area_df = pd.DataFrame(areas)[["no","name","weight","score","pct"]]
    area_df.columns = ["No.","Komponen","Bobot","Nilai","% Capaian"]
    area_df["% Capaian"] = area_df["% Capaian"].map(fmt_pct)
    result_df = pd.DataFrame(results)[["name","weight","score","pct"]]
    result_df.columns = ["Komponen Hasil","Bobot","Nilai","% Capaian"]
    result_df["% Capaian"] = result_df["% Capaian"].map(fmt_pct)
    a, b = st.columns(2)
    with a:
        st.dataframe(area_df, use_container_width=True, hide_index=True)
    with b:
        st.dataframe(result_df, use_container_width=True, hide_index=True)

    st.subheader("2. Status Tindak Lanjut per Komponen")
    tldf = tl_summary(selected_points, selected)
    if tldf.empty:
        st.info("Belum ada data tindak lanjut.")
    else:
        display = tldf.copy()
        display["TL %"] = display["TL %"].map(fmt_pct)
        st.dataframe(display, use_container_width=True, hide_index=True)

        st.subheader("3. Persentase Tindak Lanjut per Komponen Pengungkit")
        peng_names = [a["name"] for a in areas]
        chart_df = tldf[tldf["Komponen"].isin(peng_names)].copy()
        if not chart_df.empty:
            fig = px.bar(chart_df, x="TL %", y="Komponen", orientation="h", text="TL %",
                         range_x=[0,1])
            fig.update_traces(texttemplate="%{text:.1%}", textposition="outside")
            fig.update_layout(xaxis_tickformat=".0%", height=380, margin=dict(l=10,r=20,t=30,b=10))
            st.plotly_chart(fig, use_container_width=True)

    st.subheader("4. Detail Tindak Lanjut Level Poin LKE")
    st.caption("Klik komponen untuk membuka rincian pada level penilaian terkecil, misalnya A.1.i.a atau A.2.i.a sesuai struktur LKE.")
    components = list(dict.fromkeys(selected_points["component"].tolist()))
    for component in components:
        g = selected_points[selected_points["component"] == component].copy()
        pct = (g[["tl_r","tl_s","tl_t"]].sum().sum() / (len(g)*3)) if len(g) else 0
        with st.expander(f"{component}  •  TL {pct:.1%}  •  {len(g)} poin"):
            detail = g[["code","indicator","tl_r","tl_s","tl_t","pic","link","source_row"]].copy()
            detail["Catatan TPI"] = detail.pop("tl_r").map(lambda x: "✓" if x else "—")
            detail["Eviden 2024-2025"] = detail.pop("tl_s").map(lambda x: "✓" if x else "—")
            detail["Penamaan Eviden"] = detail.pop("tl_t").map(lambda x: "✓" if x else "—")
            detail = detail.rename(columns={"code":"Kode","indicator":"Poin LKE","pic":"PIC","link":"Link Eviden","source_row":"Baris Sumber"})
            st.dataframe(detail[["Kode","Poin LKE","Catatan TPI","Eviden 2024-2025","Penamaan Eviden","PIC","Link Eviden","Baris Sumber"]],
                         use_container_width=True, hide_index=True,
                         column_config={
                             "Link Eviden": st.column_config.LinkColumn("Link Eviden", display_text="Buka Eviden")
                         })

elif page == "Admin":
    st.title("🔐 Admin")
    st.caption("Fitur ini digunakan untuk memperbarui atau menambahkan data satker.")

    if not is_admin():
        password = st.text_input("Password Admin", type="password")
        if st.button("Login", type="primary"):
            expected = admin_password()
            if expected and hmac.compare_digest(password, expected):
                st.session_state["admin_authenticated"] = True
                st.rerun()
            else:
                st.error("Password tidak sesuai atau ADMIN_PASSWORD belum dikonfigurasi.")
        st.info("Viewer tidak memerlukan login. Hanya Admin yang dapat mengakses fitur upload.")
        st.stop()

    if st.button("Logout"):
        st.session_state["admin_authenticated"] = False
        st.rerun()

    st.success("Mode Admin aktif.")
    uploaded = st.file_uploader(
        "Upload file LKE (.xlsx)",
        type=["xlsx"],
        accept_multiple_files=True,
        help="Upload file LKE per satker. File baru akan menambahkan satker; nama satker yang sama akan diperbarui.",
    )

    if uploaded:
        entries = []
        for f in uploaded:
            inferred = re.sub(r"\.xlsx$", "", f.name, flags=re.I)
            inferred = re.sub(r"^LKE\s*", "", inferred, flags=re.I)
            if "Kanwil" in inferred:
                inferred = "Kanwil BPN Provinsi Gorontalo"
            elif "Kantah" in inferred:
                inferred = inferred.replace("Kab ", "Kabupaten ")
            name = st.text_input(f"Nama Satker — {f.name}", value=inferred, key=f"satker_{f.name}")
            entries.append((f, name.strip()))

        if st.button("Import / Update Dashboard", type="primary"):
            errors = []
            for f, satker in entries:
                try:
                    raw = f.getvalue()
                    s = extract_summary(raw, satker, f.name)
                    p = extract_points(raw, satker)
                    save_import(s, p)
                except Exception as e:
                    errors.append(f"{f.name}: {e}")
            if errors:
                for e in errors:
                    st.error(e)
            else:
                st.success("Data berhasil diimpor. Satker baru ditambahkan dan satker dengan nama sama diperbarui.")
                st.rerun()

    current, _ = load_data()
    st.subheader("Data Satker Saat Ini")
    if not current.empty:
        st.dataframe(
            current[["satker","total_rb","pengungkit","min_area_pct","status","updated_at","source_file"]]
            .rename(columns={
                "satker":"Satker","total_rb":"Nilai RB","pengungkit":"Pengungkit",
                "min_area_pct":"Min Area","status":"Status","updated_at":"Update","source_file":"File Sumber"
            }),
            use_container_width=True, hide_index=True,
        )

    st.warning(
        "Untuk deployment internet, gunakan password yang kuat dan simpan di secrets/environment variable. "
        "Untuk lingkungan Google Workspace internal, autentikasi akun Google/allowlist admin lebih disarankan "
        "daripada password bersama."
    )
